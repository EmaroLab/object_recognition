var searchData=
[
  ['ros_20object_20recognition_20using_20pitt_20_2b_20tensorflow',['ROS object recognition using Pitt + Tensorflow',['../index.html',1,'']]]
];
