var searchData=
[
  ['threshold',['threshold',['../classmerger_1_1merger.html#a8a0bb503a733ef1b138f8e176cb608f5',1,'merger.merger.threshold()'],['../classresult__manipulation_1_1_result_manipulation.html#a8dc19c552662e24dc3f64e7dca8fae18',1,'result_manipulation.ResultManipulation.threshold()'],['../classresults_1_1results.html#a05fa5b0aff7e2f643291cfbd0a18b551',1,'results.results.threshold()']]]
];
