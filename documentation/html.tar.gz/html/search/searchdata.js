var indexSectionsWithContent =
{
  0: "_abcdilmort",
  1: "amor",
  2: "abmor",
  3: "_acdir",
  4: "clrt",
  5: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

