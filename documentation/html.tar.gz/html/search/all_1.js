var searchData=
[
  ['add_5fbatch_5fdataprop_5fto_5find',['add_batch_dataprop_to_ind',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html#a8ffd218532e67bf47c4adb32cc1d2779',1,'armor_api::armor_manipulation_client::ArmorManipulationClient']]],
  ['add_5fcoefficients',['add_coefficients',['../classresult__manipulation_1_1_result_manipulation.html#a2361185c88198e6e3ab190bcef5f9796',1,'result_manipulation::ResultManipulation']]],
  ['add_5fdataprop_5fto_5find',['add_dataprop_to_ind',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html#a59f27571b6cf703c977a7499012f56e4',1,'armor_api::armor_manipulation_client::ArmorManipulationClient']]],
  ['add_5find_5fto_5fclass',['add_ind_to_class',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html#a838c86bd80987124f99079377c0e1a1a',1,'armor_api::armor_manipulation_client::ArmorManipulationClient']]],
  ['add_5fnew_5findividual_5fand_5fproperties',['add_new_individual_and_properties',['../classresult__manipulation_1_1_result_manipulation.html#a08d0e6c61491c1a5fc3fa924a3177ba5',1,'result_manipulation::ResultManipulation']]],
  ['add_5fobjectprop_5fto_5find',['add_objectprop_to_ind',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html#a5cc24c19cd97e8b4573d08916e5835fa',1,'armor_api::armor_manipulation_client::ArmorManipulationClient']]],
  ['armor_5fmanipulation_5fclient',['armor_manipulation_client',['../namespacearmor__api_1_1armor__manipulation__client.html',1,'armor_api']]],
  ['armormanipulationclient',['ArmorManipulationClient',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html',1,'armor_api::armor_manipulation_client']]]
];
