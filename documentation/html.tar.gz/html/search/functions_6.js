var searchData=
[
  ['signal_5fhandler',['signal_handler',['../namespaceresults.html#a7787684e1c6527926de88b3a3b544cfc',1,'results']]]
];
