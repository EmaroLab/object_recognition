var searchData=
[
  ['merger',['merger',['../classmerger_1_1merger.html',1,'merger']]]
];
