var searchData=
[
  ['merger',['merger',['../namespacemerger.html',1,'']]]
];
