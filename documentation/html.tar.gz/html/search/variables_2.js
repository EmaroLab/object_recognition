var searchData=
[
  ['res',['res',['../classresults_1_1results.html#aec862c1b1a9b8b636933f696a3e9fae3',1,'results::results']]]
];
