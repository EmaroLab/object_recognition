var searchData=
[
  ['delete_5fshapes_5fcoefficients',['delete_shapes_coefficients',['../classobjects_1_1_object.html#a8630014eaa4d079ec0069921812ce0e4',1,'objects::Object']]],
  ['detection',['detection',['../classrostensorflow_1_1_ros_tensor_flow.html#ad332542de34047b900465ea9ad913396',1,'rostensorflow::RosTensorFlow']]]
];
