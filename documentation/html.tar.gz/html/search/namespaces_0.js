var searchData=
[
  ['armor_5fmanipulation_5fclient',['armor_manipulation_client',['../namespacearmor__api_1_1armor__manipulation__client.html',1,'armor_api']]]
];
