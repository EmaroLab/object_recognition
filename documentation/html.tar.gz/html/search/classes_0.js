var searchData=
[
  ['armormanipulationclient',['ArmorManipulationClient',['../classarmor__api_1_1armor__manipulation__client_1_1_armor_manipulation_client.html',1,'armor_api::armor_manipulation_client']]]
];
